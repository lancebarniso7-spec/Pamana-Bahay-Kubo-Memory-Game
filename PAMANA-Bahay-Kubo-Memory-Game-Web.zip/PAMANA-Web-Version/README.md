# PAMANA: Bahay Kubo Memory Match — Web Version

A browser-friendly version of the Filipino-themed memory matching game.

## Run locally
Open `index.html` in a modern browser. The `assets` folder must stay beside it.

## GitHub Pages
Upload `index.html` and the `assets` folder to the repository, then enable GitHub Pages from **Settings → Pages → Deploy from a branch → main → / (root)**.

The project site will use the pattern:
`https://lancebarniso7-spec.github.io/Pamana-Bahay-Kubo-Memory-Game/`

The URL only works after GitHub Pages is enabled and the files are uploaded.
